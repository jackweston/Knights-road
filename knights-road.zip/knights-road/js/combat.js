// Very simple turn combat loop
function attack(attacker, defender){
  if(attacker.stamina<=0){ log(attacker.name + " is exhausted!"); return false; }
  const weapon = attacker.equipment.weapons[0] || { dmg:5, type:"unarmed", stamina:5 };
  attacker.stamina = Math.max(0, attacker.stamina - weapon.stamina*attacker.stats.staminaCost);
  const base = attacker.stats.attack + weapon.dmg;
  let dmg = Math.max(1, Math.floor(base - defender.stats.defense));
  if(Math.random()*100 < attacker.stats.crit){
    dmg*=2;
    log(attacker.name + " CRITS with " + weapon.type + " for " + dmg + " dmg!");
  } else {
    log(attacker.name + " hits with " + weapon.type + " for " + dmg + " dmg.");
  }
  defender.hp -= dmg;
  if(defender.hp<=0){ log(defender.name + " is defeated!"); return true; }
  return false;
}

function battle(player, enemy){
  log("⚔️ " + player.name + " vs " + enemy.name);
  while(player.hp>0 && enemy.hp>0){
    if(attack(player,enemy)) break;
    if(attack(enemy,player)) break;
  }
  log("🏁 End: " + player.name + " HP:" + player.hp + " | " + enemy.name + " HP:" + enemy.hp);
}
