// Shared helpers & rank utilities
const ranks = ["F","E","D","C","B","A","S","S+","S++","S+++"];

function getRankIndex(rank){ return ranks.indexOf(rank); }

function getRandomRank(floor){
  const clamped = Math.min(floor, ranks.length-1);
  const variance = Math.floor(Math.random()*3) - 1; // -1..+1
  const idx = Math.max(0, Math.min(ranks.length-1, clamped + variance));
  return ranks[idx];
}

function log(msg){
  const box = document.getElementById("log");
  if(!box) return;
  const line = document.createElement("div");
  line.textContent = msg;
  box.appendChild(line);
  box.scrollTop = box.scrollHeight;
}
