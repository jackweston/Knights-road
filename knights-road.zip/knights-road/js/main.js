let player, currentFloor=1;

function startGame(){
  document.getElementById("menu").style.display="none";
  document.getElementById("play").style.display="block";
  currentFloor=1;
  player=createCharacter("Knight",currentFloor,"player");
  for(let i=0;i<3;i++){ equipItem(player,generateLoot(currentFloor)); }
  updateFloorInfo();
  log("A new journey begins...");
}

function updateFloorInfo(){
  document.getElementById("floorInfo").innerText=
    "Floor " + currentFloor + " | HP:" + player.hp + "/" + player.maxHP + " | Stamina:" + player.stamina;
}

function explore(){
  const enemy=createCharacter("Enemy",currentFloor,"enemy");
  for(let i=0;i<2;i++){ equipItem(enemy,generateLoot(currentFloor)); }
  battle(player,enemy);
  if(player.hp>0){
    const loot=generateLoot(currentFloor);
    equipItem(player,loot);
    log("Looted: " + loot.category + " (" + loot.type + ") Rank:" + loot.rank);
  }
  updateFloorInfo();
}

function nextFloor(){
  currentFloor++;
  player.hp=player.maxHP; player.stamina=100;
  updateFloorInfo();
  log("You descend to floor " + currentFloor + "...");
}

// Wire buttons
window.addEventListener("DOMContentLoaded", () => {
  document.getElementById("btnNew").addEventListener("click", startGame);
  document.getElementById("btnExplore").addEventListener("click", explore);
  document.getElementById("btnVendor").addEventListener("click", visitVendor);
  document.getElementById("btnNext").addEventListener("click", nextFloor);
});
