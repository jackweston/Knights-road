// Player/enemy structs and stat aggregation
function createCharacter(name, floor, type="player"){
  return {
    name, type,
    rank:getRandomRank(floor),
    maxHP:50 + floor*10, hp:50 + floor*10,
    stamina:100,
    equipment:{ weapons:[], armor:{}, jewelry:{}, talismans:[] },
    stats:{attack:0, defense:0, crit:0, staminaCost:1},
    gold:0, silver:0, copper:0
  };
}

function equipItem(char,item){
  if(item.category==="weapon"){ char.equipment.weapons.push(item); }
  else if(item.category==="armor"){ char.equipment.armor[item.type]=item; }
  else if(item.category==="jewelry"){ char.equipment.jewelry[item.type]=item; }
  else if(item.category==="talisman"){ char.equipment.talismans.push(item); }
  updateStats(char);
}

function updateStats(char){
  let atk=0,def=0,crit=0,stamCost=1;
  for(const w of char.equipment.weapons){ atk+=w.dmg; }
  for(const k in char.equipment.armor){ if(char.equipment.armor[k]) def+=char.equipment.armor[k].defense; }
  for(const j in char.equipment.jewelry){
    const it = char.equipment.jewelry[j];
    if(!it) continue;
    if(it.bonus==="+crit") crit+=5+getRankIndex(it.rank);
    if(it.bonus==="-stamina") stamCost*=0.9;
  }
  for(const t of char.equipment.talismans){
    if(t.type==="strength") atk+=5+getRankIndex(t.rank)*2;
    if(t.type==="wisdom") def+=3+getRankIndex(t.rank);
  }
  char.stats={attack:atk, defense:def, crit, staminaCost:stamCost};
}
