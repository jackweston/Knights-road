// Vendor stub (every 5 floors)
function visitVendor(){
  if(currentFloor%5!==0){ log("No vendor on this floor."); return; }
  log("Vendor appears... offering wares.");
  if(Math.random()<0.5){ log("You find a mercenary for hire! Rank:" + getRandomRank(currentFloor)); }
}
