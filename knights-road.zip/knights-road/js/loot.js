// Loot generation & scaling
const weaponTypes = {
  sword:{ baseDmg:10, stamina:10, type:"sword" },
  axe:{ baseDmg:20, stamina:20, type:"axe" },
  bow:{ baseDmg:8, stamina:5, type:"bow" },
  staff:{ baseDmg:12, stamina:15, type:"staff" }
};

const armorTypes = ["helmet","chestplate","leggings","boots"];
const jewelryTypes = ["ring","necklace"];
const talismanTypes = ["fire","ice","poison","strength","wisdom"];

function generateLoot(floor){
  const category = ["weapon","armor","jewelry","talisman"][Math.floor(Math.random()*4)];
  const rank = getRandomRank(floor);
  
  if(category==="weapon"){
    const key = Object.keys(weaponTypes)[Math.floor(Math.random()*Object.keys(weaponTypes).length)];
    const w = weaponTypes[key];
    return { category, type:key, rank, dmg:w.baseDmg + getRankIndex(rank)*2, stamina:w.stamina };
  }
  if(category==="armor"){
    const slot = armorTypes[Math.floor(Math.random()*armorTypes.length)];
    return { category, type:slot, rank, defense:2 + getRankIndex(rank)*2 };
  }
  if(category==="jewelry"){
    const slot = jewelryTypes[Math.floor(Math.random()*jewelryTypes.length)];
    return { category, type:slot, rank, bonus:(slot==="ring")?"+crit":"-stamina" };
  }
  if(category==="talisman"){
    const slot = talismanTypes[Math.floor(Math.random()*talismanTypes.length)];
    return { category, type:slot, rank, effect:slot+"+"+(5+getRankIndex(rank)*5) };
  }
}
