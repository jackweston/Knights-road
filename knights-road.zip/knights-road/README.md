# Knight's Road (Prototype)

A minimal modular prototype of the mid‑1500s knight-themed tower crawler in plain HTML/JS.

## Run
Open `index.html` in any modern browser. No build tools required.

## Structure
- `index.html` – entry point
- `css/style.css` – styles
- `js/utils.js` – helpers & rank tables
- `js/loot.js` – loot generation
- `js/characters.js` – player/enemy structs & stat aggregation
- `js/combat.js` – simple turn-based combat function
- `js/vendor.js` – vendor placeholder (spawns every 5 floors)
- `js/main.js` – UI wiring and gameplay loop
